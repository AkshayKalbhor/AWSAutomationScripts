#!/bin/bash
chmod 755 /Script/bin/*